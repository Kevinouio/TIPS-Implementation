// ============================================================================
// parser.cpp - Recursive descent parser that BUILDS the AST 
// ----------------------------------------------------------------------------
// Author: Derek Willis (Fall 2025)
// ============================================================================

#include "parser.h"
#include "lexer.h"
#include "debug.h"
#include <stdexcept>
#include <string>
using namespace std;

// Provided by the lexer (Flex)
extern int yylex();
extern char* yytext;
extern FILE* yyin;


// Single-token lookahead
static int lookahead = 0;

// Advance to the next token
static void next() {
    lookahead = yylex();
    if (gDebug) {
        if (lookahead == TOK_EOF) dbg("next: TOK_EOF");
        else dbg(string("next: ") + tokenName(lookahead) + " (" + yytext + ")");
    }
}

// Match a specific token and return its lexeme, or throw with the given message.
static string expect(int tok, const char* msgIfMismatch) {
    if (lookahead == tok) {
        string lex = yytext;
        if (gDebug) dbg(string("match ") + tokenName(tok) + " (" + lex + ")");
        next();
        return lex;
    }
    if (gDebug) {
        dbg(string("mismatch: got ") + tokenName(lookahead) +
            ", expected " + tokenName(tok));
    }
    throw runtime_error(msgIfMismatch);
}


// TODO: define and implement parseSentence, parseNounPhrase, parseAdjectivePhrase,
//        parseVerbPhrase




// Entry point: initialize, parse, enforce EOF
unique_ptr<Sentence> parseStart() {
    next();                      // prime lookahead
    auto root = parseSentence(); // may throw on first syntax error
    if (lookahead != TOK_EOF) {
        throw runtime_error("Extra input after complete sentence.");
    }
    return root;
}
